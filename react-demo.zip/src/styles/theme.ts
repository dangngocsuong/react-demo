const theme = {
	colors: {
		white: '#fff',
		shark: '#23272F',
		dovegray: '#6e6e6e',
		monza: '#e40914',
		milanored: '#b30710',
		gray:'#1e1e1e',
		mineshaft: '#252525',
		boulder: '#7C7C7C',
		codgray: '#111'
	}
};

export default theme;