import { Input as AntInput, Typography } from 'antd';
import { ChangeEvent, FunctionComponent, useState } from 'react';
import { Control, RegisterOptions, get, useController } from 'react-hook-form';

const Input: FunctionComponent<{
    name: string;
    control: Control;
    type?: string;
    rules?: RegisterOptions;
    value?: string;
    placeholder?: string;
    onChange?: (value: object) => void;
    onBlur?: () => void;
    onFocus?: () => void;
    disabled?: boolean;
}> = ({
    name,
    control,
    type,
    rules,
    value,
    placeholder,
    onChange,
    onBlur,
    onFocus,
    disabled,
}) => {

        const { Text } = Typography;
        const { field, formState } = useController({
            control,
            name,
            rules,
            defaultValue: value,
        });
        // const errors = get(formState, 'errors', {});
        // const isError = get(errors, name);
        const errors = get(formState.errors, name);

        //const [inputtype, setInputtype] = useState(type);
        //console.log(name);

        const handleChange = (event: ChangeEvent<HTMLInputElement>): void => {
            field.onChange(event);
            onChange(event);
            // console.log(typeof event);
        }
        //console.log(onChange);

        return (
            <>
                <AntInput
                    type = {type}
                    name={name}
                    control={control}
                    value={field.value}
                    placeholder={placeholder}
                    onChange={handleChange}
                    onBlur={onBlur}
                    onFocus={onFocus}
                    disabled={disabled}
                    status={errors && 'error'}
                />
                {errors && <Text type="danger">{errors.message}</Text>}
            </>
        );
    }
// Input.defaultProps = {
//     onChange: {},
// };
export default Input;